
const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();

const Todo = require("../models/todo");
const Event = require("../models/Event");
const Registration = require("../models/Registration");

// -------------------- TODO ROUTES --------------------

router.get("/todos", async (req, res) => {
  try {
    const todos = await Todo.find({}, "action");
    res.json(todos);
  } catch (error) {
    console.error("Fetch todos:", error);
    res.status(500).json({ message: "Failed to fetch todos." });
  }
});

router.post("/todos", async (req, res) => {
  try {
    const action = req.body?.action;

    if (typeof action !== "string" || !action.trim()) {
      return res.status(400).json({
        message: "The input field is empty.",
      });
    }

    const todo = await Todo.create({ action: action.trim() });
    res.status(201).json(todo);
  } catch (error) {
    console.error("Create todo:", error);
    res.status(500).json({ message: "Failed to create todo." });
  }
});

router.delete("/todos/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid todo ID." });
    }

    const todo = await Todo.findByIdAndDelete(req.params.id);

    if (!todo) {
      return res.status(404).json({ message: "Todo not found." });
    }

    res.json({ message: "Todo deleted successfully." });
  } catch (error) {
    console.error("Delete todo:", error);
    res.status(500).json({ message: "Failed to delete todo." });
  }
});

// -------------------- EVENT ROUTES --------------------

router.get("/events", async (req, res) => {
  try {
    const events = await Event.find().sort({ _id: 1 });
    res.json(events);
  } catch (error) {
    console.error("Fetch events:", error);
    res.status(500).json({ message: "Failed to fetch events." });
  }
});

router.get("/events/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid event ID." });
    }

    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({ message: "Event not found." });
    }

    res.json(event);
  } catch (error) {
    console.error("Fetch event:", error);
    res.status(500).json({ message: "Failed to fetch event." });
  }
});

// -------------------- STUDENT REGISTRATION --------------------

router.post("/events/:id/register", async (req, res) => {
  try {
    const { studentName, email, department } = req.body || {};
    const eventId = req.params.id;

    if (!mongoose.isValidObjectId(eventId)) {
      return res.status(400).json({ message: "Invalid event ID." });
    }

    if (
      typeof studentName !== "string" ||
      typeof email !== "string" ||
      typeof department !== "string" ||
      !studentName.trim() ||
      !email.trim() ||
      !department.trim()
    ) {
      return res.status(400).json({
        message: "Name, email, and department are required.",
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return res.status(400).json({
        message: "Please enter a valid email address.",
      });
    }

    const event = await Event.findById(eventId);

    if (!event) {
      return res.status(404).json({ message: "Event not found." });
    }

    if (event.status !== "Registration Open") {
      return res.status(400).json({
        message: "Registration is not open for this event.",
      });
    }

    // Check for an existing registration before creating another.
    const existing = await Registration.findOne({
      email: normalizedEmail,
      event: event._id,
    });

    if (existing) {
      return res.status(409).json({
        message: "This email is already registered for this event.",
      });
    }

    const registration = await Registration.create({
      studentName: studentName.trim(),
      email: normalizedEmail,
      department: department.trim(),
      event: event._id,
    });

    const registrations = await Registration.countDocuments({
      event: event._id,
    });

    await Event.updateOne(
      { _id: event._id },
      { $set: { registrations } }
    );

    return res.status(201).json({
      message: `Successfully registered for ${event.title}!`,
      registration: {
        id: registration._id,
        studentName: registration.studentName,
        email: registration.email,
        department: registration.department,
        event: event.title,
      },
      registrations,
    });
  } catch (error) {
    // MongoDB unique-index duplicate key error.
    if (error.code === 11000) {
      return res.status(409).json({
        message: "This email is already registered for this event.",
      });
    }

    console.error("Student registration error:", error);

    return res.status(500).json({
      message: "Server error while registering. Check the backend terminal.",
    });
  }
});

// -------------------- VIEW EVENT PARTICIPANTS --------------------

router.get("/events/:id/registrations", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid event ID." });
    }

    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({ message: "Event not found." });
    }

    const participants = await Registration.find({
      event: event._id,
    })
      .select("studentName email department createdAt")
      .sort({ createdAt: -1 });

    return res.json(participants);
  } catch (error) {
    console.error("Fetch participants:", error);
    return res.status(500).json({
      message: "Failed to fetch participants.",
    });
  }
});

module.exports = router;