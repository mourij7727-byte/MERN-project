
require('dotenv').config();

const mongoose = require('mongoose');
const Event = require('./models/Event');

const events = [
  {
    title: 'AI Hackathon',
    date: '15 October 2026',
    location: 'Main Auditorium',
    description: 'Build innovative AI solutions with your team.',
    status: 'Registration Open',
  },
  {
    title: 'Web Development Workshop',
    date: '20 October 2026',
    location: 'Computer Lab',
    description: 'Learn modern web development and build projects.',
    status: 'Registration Open',
  },
  {
    title: 'Coding Contest',
    date: '25 October 2026',
    location: 'Programming Lab',
    description: 'Test your programming skills and solve challenges.',
    status: 'Registration Open',
  },
  {
    title: 'Project Expo',
    date: '30 October 2026',
    location: 'College Ground',
    description: 'Showcase your engineering projects.',
    status: 'Upcoming',
  },
];

async function seedEvents() {
  try {
    const mongoUri = process.env.MONGO_DB_URI;

    if (!mongoUri) {
      throw new Error('MONGO_DB_URI is missing from your .env file');
    }

    await mongoose.connect(mongoUri);

    for (const event of events) {
      await Event.updateOne(
        { title: event.title },
        { $setOnInsert: event },
        { upsert: true }
      );
    }

    console.log('✅ Sample events added or already exist.');
  } catch (error) {
    console.error('❌ Seeding failed:', error.stack || error.message);
    process.exitCode = 1;
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
  }
}

seedEvents();