
import { useEffect, useState } from "react";
import axios from "axios";
import "../App.css";

const API = "/api";

export default function Register() {
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({
    studentName: "",
    email: "",
    department: "",
    eventId: "",
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);

  async function loadEvents() {
    try {
      const response = await axios.get(`${API}/events`);
      setEvents(response.data);
    } catch (error) {
      console.error("Loading events failed:", error);
      setMessage("Unable to load events. Please restart the backend.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadEvents();
  }, []);

  function handleChange(event) {
    setForm((previous) => ({
      ...previous,
      [event.target.name]: event.target.value,
    }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage("");
    setSuccess(false);

    if (!form.eventId) {
      setMessage("Please select an event.");
      return;
    }

    setSubmitting(true);

    try {
      const response = await axios.post(
        `${API}/events/${form.eventId}/register`,
        {
          studentName: form.studentName.trim(),
          email: form.email.trim(),
          department: form.department.trim(),
        },
        {
          headers: { "Content-Type": "application/json" },
          timeout: 15000,
        }
      );

      setSuccess(true);
      setMessage(response.data.message || "Registration successful!");

      setForm({
        studentName: "",
        email: "",
        department: "",
        eventId: "",
      });

      await loadEvents();
    } catch (error) {
      console.error("Registration request failed:", {
        message: error.message,
        status: error.response?.status,
        response: error.response?.data,
      });

      if (error.response?.data?.message) {
        setMessage(error.response.data.message);
      } else if (error.code === "ECONNABORTED") {
        setMessage("The request timed out. Please try again.");
      } else if (!error.response) {
        setMessage(
          "Cannot connect to the server. Make sure the backend is running."
        );
      } else {
        setMessage(
          `Registration failed (HTTP ${error.response.status}). Please try again.`
        );
      }
    } finally {
      setSubmitting(false);
    }
  }

  const openEvents = events.filter(
    (event) => event.status === "Registration Open"
  );

  return (
    <main className="register-page">
      <section className="register-card">
        <div className="register-heading">
          <div className="register-icon">🚀</div>
          <p className="register-eyebrow">CAMPUSSPHERE / STUDENT PORTAL</p>
          <h1>Join the Mission</h1>
          <p>Choose your event and reserve your place in the universe.</p>
        </div>

        {message && (
          <div
            className={`register-message ${
              success ? "register-success" : "register-error"
            }`}
            role="status"
          >
            {message}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label htmlFor="studentName">Full Name</label>
          <input
            id="studentName"
            name="studentName"
            type="text"
            placeholder="Enter your full name"
            value={form.studentName}
            onChange={handleChange}
            maxLength={100}
            autoComplete="name"
            required
          />

          <label htmlFor="email">College Email</label>
          <input
            id="email"
            name="email"
            type="email"
            placeholder="student@example.com"
            value={form.email}
            onChange={handleChange}
            maxLength={254}
            autoComplete="email"
            required
          />

          <label htmlFor="department">Department</label>
          <select
            id="department"
            name="department"
            value={form.department}
            onChange={handleChange}
            required
          >
            <option value="">Choose your department</option>
            <option value="CSE">Computer Science (CSE)</option>
            <option value="IT">Information Technology (IT)</option>
            <option value="ECE">Electronics (ECE)</option>
            <option value="EEE">Electrical (EEE)</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Civil">Civil</option>
            <option value="Other">Other</option>
          </select>

          <label htmlFor="eventId">Select Event</label>
          <select
            id="eventId"
            name="eventId"
            value={form.eventId}
            onChange={handleChange}
            disabled={loading || openEvents.length === 0}
            required
          >
            <option value="">
              {loading ? "Loading events..." : "Choose an event"}
            </option>
            {openEvents.map((event) => (
              <option key={event._id} value={event._id}>
                {event.title} — {event.date}
              </option>
            ))}
          </select>

          {!loading && openEvents.length === 0 && (
            <p>No events are currently accepting registrations.</p>
          )}

          <button
            className="register-submit"
            type="submit"
            disabled={submitting || loading || openEvents.length === 0}
          >
            {submitting ? "Registering..." : "Confirm Registration →"}
          </button>
        </form>

        <p className="register-note">
          ✦ Your email can be registered once per event.
        </p>
      </section>
    </main>
  );
}