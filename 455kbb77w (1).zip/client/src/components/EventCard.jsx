function EventCard({ event, index, onRegister }) {
  const icons = ["🤖", "💻", "🏆", "🚀", "🎤"];

  return (
    <div className="event-card">
      <div className="event-image">
        {icons[index % icons.length]}
      </div>

      <div className="event-info">
        <span className="tag">{event.status}</span>

        <h3>{event.title}</h3>

        <p>{event.description}</p>

        <div className="event-details">
          <span>📅 {event.date}</span>
          <span>📍 {event.location}</span>
        </div>

        <button onClick={() => onRegister(event.id)}>
          Register Now →
        </button>
      </div>
    </div>
  );
}

export default EventCard;