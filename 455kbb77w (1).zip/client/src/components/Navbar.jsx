function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <div className="logo-icon">M</div>

        <div>
          <h2>MAHENDRA</h2>
          <span>COLLEGE OF ENGINEERING</span>
        </div>
      </div>

      <div className="nav-links">
        <a href="#home">Home</a>
        <a href="#events">Events</a>
        <a href="#about">About</a>

        <button className="login-btn">
          Login
        </button>
      </div>
    </nav>
  );
}

export default Navbar;