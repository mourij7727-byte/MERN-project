function Hero() {
  const exploreEvents = () => {
    document
      .getElementById("events")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  return (
    <section className="hero" id="home">

      <div className="hero-content">

        <div className="college-title">

          <div className="college-logo">
            M
          </div>

          <div>
            <h2>MAHENDRA</h2>
            <h3>COLLEGE OF ENGINEERING</h3>
          </div>

        </div>

        <div className="department">
          <span>DEPARTMENT OF</span>
          <strong>INFORMATION TECHNOLOGY</strong>
        </div>

        <div className="line"></div>

        <h1>
          College Events
          <br />
          <span>2026</span>
        </h1>

        <p>
          Explore technical events, workshops,
          symposiums and exciting activities
          organized by the
          <b> Department of Information Technology.</b>
        </p>

        <div className="hero-buttons">

          <button
            className="primary-btn"
            onClick={exploreEvents}
          >
            Explore Events →
          </button>

          <button className="secondary-btn">
            Learn More
          </button>

        </div>

      </div>

      <div className="hero-card">

        <div className="circle">
          IT
        </div>

        <h3>
          Information Technology
        </h3>

        <p>
          Innovate • Create • Transform
        </p>

        <div className="event-mini">

          <span>🎓</span>

          <div>
            <strong>Upcoming Events</strong>

            <small>
              Stay connected with our IT community
            </small>
          </div>

        </div>

      </div>

    </section>
  );
}

export default Hero;