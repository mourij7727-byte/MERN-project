function Footer() {
  return (
    <footer id="about">
      <div>
        <h3>Mahendra College of Engineering</h3>
        <p>Department of Information Technology</p>
      </div>

      <div className="footer-links">
        <a href="#home">Home</a>
        <a href="#events">Events</a>
        <a href="#about">About</a>
      </div>

      <p>
        © 2026 IT Department. All Rights Reserved.
      </p>
    </footer>
  );
}

export default Footer;