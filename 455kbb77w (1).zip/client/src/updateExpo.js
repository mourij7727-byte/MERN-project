
require("dotenv").config();
const mongoose = require("mongoose");
const Event = require("./models/Event");

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_DB_URI);

    const result = await Event.updateOne(
      { title: "Project Expo" },
      { $set: { status: "Registration Open" } }
    );

    console.log(
      result.matchedCount
        ? "Project Expo registration is now open!"
        : "Project Expo was not found."
    );
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

main();