
import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

export default function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [student, setStudent] = useState({
    studentName: "",
    email: "",
    department: "",
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function fetchEvents() {
    try {
      const response = await axios.get("/api/events");
      setEvents(response.data);
    } catch (error) {
      console.error("Unable to load events:", error);
      setMessage("Unable to load events. Please try again later.");
    }
  }

  useEffect(() => {
    fetchEvents();
  }, []);

  function openForm(event) {
    setSelectedEvent(event);
    setStudent({ studentName: "", email: "", department: "" });
    setMessage("");
  }

  function closeForm() {
    setSelectedEvent(null);
    setMessage("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!selectedEvent) return;

    setLoading(true);
    setMessage("");

    try {
      const response = await axios.post(
        `/api/events/${selectedEvent._id}/register`,
        student
      );

      setMessage(response.data.message || "Registration successful!");
      await fetchEvents();
    } catch (error) {
      console.error("Registration error:", error.response?.data || error);
      setMessage(
        error.response?.data?.message ||
          "Registration failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="home-page">
      <nav className="navbar">
        <a className="brand" href="#home">✦ CampusSphere</a>
        <a className="nav-register" href="#events">Explore Events ↗</a>
      </nav>

      <section className="hero" id="home">
        <div className="hero-badge">✦ YOUR CAMPUS. YOUR UNIVERSE.</div>
        <h1>Make Your Next <span>Big Moment.</span></h1>
        <p>Discover campus events, meet your people, and turn your ideas into something extraordinary.</p>
        <a className="hero-button" href="#events">Explore Events ↓</a>
        <div className="hero-stats">
          <div><strong>{events.length}</strong><span>Campus Events</span></div>
          <div><strong>{events.reduce((n, e) => n + (e.registrations || 0), 0)}</strong><span>Registrations</span></div>
          <div><strong>∞</strong><span>Possibilities</span></div>
        </div>
      </section>

      <section className="events-section" id="events">
        <div className="section-heading">
          <div>
            <p className="section-eyebrow">DISCOVER YOUR NEXT ADVENTURE</p>
            <h2>Explore Events<span>.</span></h2>
          </div>
          <p className="section-description">One campus. Endless opportunities.</p>
        </div>

        <div className="event-grid">
          {events.map((event) => (
            <article className="event-card" key={event._id}>
              <div className="event-card-top">
                <span className="event-icon">
                  {event.title === "AI Hackathon" ? "🤖" :
                   event.title === "Web Development Workshop" ? "💻" :
                   event.title === "Coding Contest" ? "🏆" : "🚀"}
                </span>
                <span className={`event-status ${event.status === "Registration Open" ? "status-open" : "status-upcoming"}`}>
                  {event.status}
                </span>
              </div>
              <h3>{event.title}</h3>
              <p className="event-description">{event.description}</p>
              <p className="event-detail">📅 {event.date}</p>
              <p className="event-detail">📍 {event.location}</p>
              <p className="event-detail">👥 Registrations: {event.registrations || 0}</p>

              <button
                className="register-button"
                onClick={() => openForm(event)}
                disabled={event.status !== "Registration Open"}
              >
                {event.status === "Registration Open" ? "Register Now →" : "Coming Soon"}
              </button>
            </article>
          ))}
        </div>
      </section>

      <footer className="footer">
        <a className="brand" href="#home">✦ CampusSphere</a>
        <p>Made for the next generation of campus innovators.</p>
        <span>© 2026 CampusSphere</span>
      </footer>

      {selectedEvent && (
        <div className="registration-overlay">
          <section className="registration-modal" role="dialog" aria-modal="true">
            <button className="modal-close" onClick={closeForm} type="button">×</button>
            <div className="modal-event-icon">🚀</div>
            <p className="section-eyebrow">EVENT REGISTRATION</p>
            <h2>Join the Mission</h2>
            <p className="modal-subtitle">Register for <strong>{selectedEvent.title}</strong></p>

            {message && <div className="register-message" role="status">{message}</div>}

            <form className="registration-form" onSubmit={handleSubmit}>
              <label htmlFor="studentName">Student Name</label>
              <input
                id="studentName"
                name="studentName"
                value={student.studentName}
                onChange={(e) => setStudent({ ...student, studentName: e.target.value })}
                placeholder="Enter your full name"
                required
              />

              <label htmlFor="email">Email Address</label>
              <input
                id="email"
                name="email"
                type="email"
                value={student.email}
                onChange={(e) => setStudent({ ...student, email: e.target.value })}
                placeholder="you@example.com"
                required
              />

              <label htmlFor="department">Department</label>
              <select
                id="department"
                value={student.department}
                onChange={(e) => setStudent({ ...student, department: e.target.value })}
                required
              >
                <option value="">Select department</option>
                <option value="CSE">Computer Science (CSE)</option>
                <option value="IT">Information Technology (IT)</option>
                <option value="ECE">Electronics (ECE)</option>
                <option value="EEE">Electrical (EEE)</option>
                <option value="Mechanical">Mechanical</option>
                <option value="Civil">Civil</option>
                <option value="Other">Other</option>
              </select>

              <button className="register-button modal-submit" type="submit" disabled={loading}>
                {loading ? "Submitting..." : "Confirm Registration →"}
              </button>
            </form>
          </section>
        </div>
      )}
    </main>
  );
}