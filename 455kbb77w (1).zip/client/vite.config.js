import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    allowedHosts: ['a13f1d96aa4b-0af41e7d-5173.ws6.app'],
    proxy: {
      '/api': 'http://localhost:5000',
    },
  },
})
